// ==UserScript==
// @name         楽天市場 画像リンクまとめて開く（右上ボタン＆大きめチェック）
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  検索結果画像にチェックボックスを付けてまとめて開ける（UI調整版）
// @match        https://search.rakuten.co.jp/search/mall/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const mainTab = window;

    // 画像にチェックボックス追加
    function addCheckboxes() {
        const images = document.querySelectorAll("a.image-link-wrapper--3XCNg > img.image--x5mNi");
        images.forEach(img => {
            if (img.parentElement.querySelector(".raf-checkbox")) return;

            const wrapper = img.parentElement;
            wrapper.style.position = "relative";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "raf-checkbox";
            checkbox.style.position = "absolute";
            checkbox.style.top = "10px";
            checkbox.style.left = "10px";
            checkbox.style.zIndex = "1000";
            checkbox.style.transform = "scale(2.5)"; // ← 大きめに
            checkbox.addEventListener("click", e => e.stopPropagation());

            wrapper.appendChild(checkbox);
        });
    }

    addCheckboxes();

    // 無限スクロール対応
    const observer = new MutationObserver(() => addCheckboxes());
    observer.observe(document.body, { childList: true, subtree: true });

    // --- ボタンコンテナを右上にまとめる ---
    const panel = document.createElement("div");
    panel.style.position = "fixed";
    panel.style.top = "20px";
    panel.style.right = "20px";
    panel.style.zIndex = "10000";
    panel.style.display = "flex";
    panel.style.flexDirection = "column";
    panel.style.gap = "10px";
    document.body.appendChild(panel);

    // ボタン生成
    function createButton(text, color) {
        const btn = document.createElement("button");
        btn.textContent = text;
        btn.style.padding = "10px";
        btn.style.backgroundColor = color;
        btn.style.color = "white";
        btn.style.fontWeight = "bold";
        btn.style.border = "none";
        btn.style.borderRadius = "5px";
        btn.style.cursor = "pointer";
        btn.style.minWidth = "200px";
        panel.appendChild(btn);
        return btn;
    }

    const openButton = createButton("チェック画像リンクを順番に開く", "green");
    const checkAllButton = createButton("全部チェック", "blue");
    const uncheckAllButton = createButton("チェック解除", "red");

    const wait = ms => new Promise(r => setTimeout(r, ms));

    // 「まとめて開く」
    openButton.addEventListener("click", async () => {
        const checkedBoxes = document.querySelectorAll("input.raf-checkbox:checked");
        if (checkedBoxes.length === 0) {
            alert("まずチェックしてください！");
            return;
        }

        for (let cb of checkedBoxes) {
            const link = cb.closest("a.image-link-wrapper--3XCNg");
            if (link && window === mainTab) {
                window.open(link.href, "_blank"); // 新しいタブで開く
                await wait(500);
                mainTab.focus();
            }
        }

        checkedBoxes.forEach(cb => cb.checked = false);
        alert("処理完了");
    });

    // 「全部チェック」
    checkAllButton.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox").forEach(cb => cb.checked = true);
    });

    // 「チェック解除」
    uncheckAllButton.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox").forEach(cb => cb.checked = false);
    });

})();
