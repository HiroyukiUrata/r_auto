// ==UserScript==
// @name         Rakuten 商品ページ 自動スクロール＋ボタン（読み込み待ち対応）
// @namespace    http://tampermonkey.net/
// @version      1.6
// @match        https://item.rakuten.co.jp/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 画面中央にスクロールボタンを作成
    const scrollButton = document.createElement('button');
    scrollButton.textContent = '商品説明までスクロール';
    scrollButton.style.position = 'fixed';
    scrollButton.style.top = '50%';
    scrollButton.style.left = '50%';
    scrollButton.style.transform = 'translate(-50%, -50%)';
    scrollButton.style.zIndex = 9999;
    scrollButton.style.padding = '12px 18px';
    scrollButton.style.backgroundColor = '#ff9900';
    scrollButton.style.color = '#fff';
    scrollButton.style.border = 'none';
    scrollButton.style.borderRadius = '8px';
    scrollButton.style.cursor = 'pointer';
    scrollButton.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
    document.body.appendChild(scrollButton);

    // クリック時のスクロール
    scrollButton.addEventListener('click', () => {
        const itemArea = document.querySelector('#item-name-area');
        if (itemArea) {
            itemArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
            itemArea.focus();
        } else {
            alert('#item-name-area が見つかりません');
        }
    });

    // #item-name-area が生成されるのを監視
    const observer = new MutationObserver(() => {
        const itemArea = document.querySelector('#item-name-area');
        if (itemArea) {
            // 要素が見つかったら遅延スクロール
            setTimeout(() => {
                itemArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
                itemArea.focus();
            }, 2000); // 遅延 2秒

            observer.disconnect(); // 監視終了
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
})();
