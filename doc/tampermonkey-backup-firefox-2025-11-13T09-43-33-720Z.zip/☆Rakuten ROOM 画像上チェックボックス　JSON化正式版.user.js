// ==UserScript==
// @name         ☆Rakuten ROOM 画像上チェックボックス　JSON化正式版
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  画像上にチェックボックスを作り、ランダムチェック・全解除・まとめて開くが可能（右上にボタン整列）、収集結果をJSON化して表示、コピーで閉じる
// @match        https://room.rakuten.co.jp/search/item*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const createdSrcs = new Set();

    function addCheckboxes() {
        const images = document.querySelectorAll("div.imgLink > img.image");
        images.forEach(img => {
            if (createdSrcs.has(img.src)) return;

            const wrapper = img.parentElement;
            wrapper.style.position = "relative";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "room-checkbox";
            checkbox.style.position = "absolute";
            checkbox.style.top = "2px";
            checkbox.style.left = "2px";
            checkbox.style.zIndex = "1000";
            checkbox.style.transform = "scale(1.8)";
            checkbox.addEventListener("click", e => e.stopPropagation());

            wrapper.appendChild(checkbox);
            createdSrcs.add(img.src);
        });
    }

    addCheckboxes();
    const observer = new MutationObserver(() => addCheckboxes());
    observer.observe(document.body, { childList: true, subtree: true });

    const controlPanel = document.createElement("div");
    controlPanel.style.position = "fixed";
    controlPanel.style.top = "20px";
    controlPanel.style.right = "20px";
    controlPanel.style.zIndex = "10000";
    controlPanel.style.display = "flex";
    controlPanel.style.flexDirection = "column";
    controlPanel.style.gap = "8px";
    controlPanel.style.background = "rgba(0,0,0,0.6)";
    controlPanel.style.padding = "10px";
    controlPanel.style.borderRadius = "6px";
    controlPanel.style.boxShadow = "0 2px 6px rgba(0,0,0,0.4)";
    document.body.appendChild(controlPanel);

    function styleButton(btn) {
        btn.style.fontSize = "12px";
        btn.style.backgroundColor = "red";
        btn.style.color = "white";
        btn.style.border = "none";
        btn.style.borderRadius = "4px";
        btn.style.cursor = "pointer";
        btn.style.padding = "4px 8px";
    }

    const selectBox = document.createElement("select");
    [5,20,30,40,50].forEach(num => {
        const opt = document.createElement("option");
        opt.value = num;
        opt.textContent = num;
        selectBox.appendChild(opt);
    });
    selectBox.style.fontSize = "12px";
    controlPanel.appendChild(selectBox);

    const randomCheckBtn = document.createElement("button");
    randomCheckBtn.textContent = "ランダムチェック";
    styleButton(randomCheckBtn);
    controlPanel.appendChild(randomCheckBtn);

    const uncheckAllBtn = document.createElement("button");
    uncheckAllBtn.textContent = "チェック解除";
    styleButton(uncheckAllBtn);
    controlPanel.appendChild(uncheckAllBtn);

    const openButton = document.createElement("button");
    openButton.textContent = "まとめて開く";
    styleButton(openButton);
    controlPanel.appendChild(openButton);

    const wait = ms => new Promise(r => setTimeout(r, ms));

    randomCheckBtn.addEventListener("click", async () => {
        let allBoxes = Array.from(document.querySelectorAll("input.room-checkbox"));
        const requiredNum = parseInt(selectBox.value, 10);

        while (allBoxes.length < requiredNum) {
            window.scrollBy(0, 600);
            await wait(700);
            addCheckboxes();
            allBoxes = Array.from(document.querySelectorAll("input.room-checkbox"));
        }

        allBoxes.forEach(cb => cb.checked = false);

        const shuffled = allBoxes.sort(() => Math.random() - 0.5);
        const selected = shuffled.slice(0, requiredNum);
        selected.forEach(cb => cb.checked = true);

        console.log("チェックされた画像 alt:");
        selected.forEach(cb => {
            const img = cb.closest("div.imgLink").querySelector("img.image");
            if (img) console.log(img.alt);
        });
    });

    uncheckAllBtn.addEventListener("click", () => {
        const checked = document.querySelectorAll("input.room-checkbox:checked");
        checked.forEach(cb => cb.checked = false);
        alert("すべて解除しました！");
    });

    openButton.addEventListener("click", async () => {
        const checkedBoxes = Array.from(document.querySelectorAll("input.room-checkbox:checked"));
        if (checkedBoxes.length === 0) {
            alert("まずチェックしてください！");
            return;
        }

        const collectedUrls = [];
        const collectedThumbnails = [];
        const originalOpen = window.open;

        window.open = function(url, name, specs) {
            if (url && url.includes("item.rakuten.co.jp")) {
                collectedUrls.push(url);
                console.log("URL回収:", url);
                return null;
            }
            return originalOpen.apply(this, arguments);
        };

        for (const cb of checkedBoxes) {
            const imgDiv = cb.closest("div.imgLink");
            if (!imgDiv) continue;

            const thumbImg = imgDiv.querySelector("img.image");
            if (thumbImg) {
                collectedThumbnails.push(thumbImg.src);
                console.log("サムネイルURL:", thumbImg.src);
            }

            imgDiv.click();
            await wait(900);

            const buyBtn = document.querySelector("div.buy-button.ng-binding");
            if (buyBtn) buyBtn.click();

            const closeBtn = document.querySelector(".close-button, .popup-close");
            if (closeBtn) closeBtn.click();

            await wait(400);
        }

        checkedBoxes.forEach(cb => cb.checked = false);
        window.open = originalOpen;

        if (collectedUrls.length === 0) {
            alert("URLは収集できませんでした。");
            return;
        }

        const result = collectedUrls.map((url, i) => ({
            page_url: url,
            image_url: collectedThumbnails[i] || ""
        }));

        const jsonBox = document.createElement("textarea");
        jsonBox.style.position = "fixed";
        jsonBox.style.top = "50px";
        jsonBox.style.left = "50%";
        jsonBox.style.transform = "translateX(-50%)";
        jsonBox.style.width = "600px";
        jsonBox.style.height = "400px";
        jsonBox.style.zIndex = "20000";
        jsonBox.style.background = "white";
        jsonBox.style.color = "black";
        jsonBox.style.fontSize = "12px";
        jsonBox.style.padding = "10px";
        jsonBox.value = JSON.stringify(result, null, 2);
        document.body.appendChild(jsonBox);

        const copyBtn = document.createElement("button");
        copyBtn.textContent = "JSONコピー";
        styleButton(copyBtn);
        copyBtn.style.position = "fixed";
        copyBtn.style.top = "10px";
        copyBtn.style.left = "50%";
        copyBtn.style.transform = "translateX(-50%)";
        copyBtn.style.backgroundColor = "green";
        copyBtn.style.zIndex = "20001";
        document.body.appendChild(copyBtn);

        copyBtn.addEventListener("click", () => {
            jsonBox.select();
            document.execCommand("copy");
            alert("JSONをコピーしました ✅");
            // コピー後にテキストボックスとボタンを削除
            jsonBox.remove();
            copyBtn.remove();
        });

        console.log("収集URL一覧:", collectedUrls);
        console.log("対応するサムネイルURL一覧:", collectedThumbnails);
    });

})();
