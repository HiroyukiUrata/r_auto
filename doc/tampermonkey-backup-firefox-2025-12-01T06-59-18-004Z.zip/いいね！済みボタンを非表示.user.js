// ==UserScript==
// @name         いいね！済みボタンを非表示
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  いいね済みボタンを非表示にし、少しスクロールしたら上部10%を覆う
// @match        https://room.rakuten.co.jp/search/item*
// @match        https://room.rakuten.co.jp/item*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    // いいね済みボタンを非表示
    GM_addStyle(`
        a.icon-like.isLiked {
            display: none !important;
        }
    `);

    // 上部10%を覆う要素を作成（初期は非表示）
    const topOverlay = document.createElement('div');
    topOverlay.style.position = 'fixed';
    topOverlay.style.top = '0';
    topOverlay.style.left = '0';
    topOverlay.style.width = '100%';
    topOverlay.style.height = '30vh';
    topOverlay.style.backgroundColor = 'rgba(100, 100, 100, 1)';
    topOverlay.style.zIndex = '9999';
    topOverlay.style.display = 'none'; // 初期は非表示
    document.body.appendChild(topOverlay);

    // スクロールで表示
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) { // 50px以上スクロールしたら表示
            topOverlay.style.display = 'block';
        } else {
            topOverlay.style.display = 'none';
        }
    });
})();
