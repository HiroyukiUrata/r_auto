// ==UserScript==
// @name         販売開始前／売切れ以外非表示
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  販売開始前／売切れ以外非表示 + カウンター + 30文字コピー（改行除去）
// @match        https://room.rakuten.co.jp/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    //----------------------------------------
    // カウンターボックス
    //----------------------------------------
    function insertCounterBox() {
        let box = document.getElementById("room-card-counter");
        if (!box) {
            box = document.createElement("div");
            box.id = "room-card-counter";

            box.style.position = "fixed";
            box.style.top = "10px";
            box.style.right = "10px";
            box.style.background = "rgba(0,0,0,0.8)";
            box.style.color = "white";
            box.style.padding = "8px 12px";
            box.style.borderRadius = "6px";
            box.style.fontSize = "18px";
            box.style.zIndex = "999999999999";
            box.style.border = "2px solid yellow";

            box.textContent = "Cards: ---";

            document.documentElement.appendChild(box);
        }
        return box;
    }

    //----------------------------------------
    // 右下ボタン（Copy 30chars）
    //----------------------------------------
    function insertCopyButton() {
        let btn = document.getElementById("copy-20chars-btn");
        if (!btn) {
            btn = document.createElement("button");
            btn.id = "copy-20chars-btn";

            btn.style.position = "fixed";
            btn.style.bottom = "20px";
            btn.style.right = "20px";
            btn.style.padding = "10px 16px";
            btn.style.background = "#007bff";
            btn.style.color = "white";
            btn.style.border = "none";
            btn.style.borderRadius = "8px";
            btn.style.cursor = "pointer";
            btn.style.fontSize = "16px";
            btn.style.zIndex = "999999999999";

            btn.innerText = "Copy 30chars";

            btn.onclick = async () => {
                const text = collectFirst30Chars();

                try {
                    await navigator.clipboard.writeText(text);
                    alert("クリップボードにコピーしました！");
                } catch (err) {
                    alert("クリップボードコピーに失敗しました");
                }
            };

            document.documentElement.appendChild(btn);
        }
        return btn;
    }

    //----------------------------------------
    // ★ 30文字取得（改行除去付き）
    //----------------------------------------
    function collectFirst30Chars() {
        const visibleCards = document.querySelectorAll(
            '.vertical-space--2VG7l.medium--7ss7K:not([style*="display: none"])'
        );

        const results = [];

        visibleCards.forEach(card => {
            const textEl = card.querySelector(
                '.social-text-area--22OZg.line-clamp--WhePK.show-new-line--14K__'
            );

            if (textEl) {
                let txt = textEl.innerText.trim();

                // ★改行があれば、最初の行だけにする
                let noBreak = txt.split("\n")[0];

                // ★さらに30文字だけ残す
                results.push(noBreak.slice(0, 30));
            }
        });

        return results.join("\n");
    }

    //----------------------------------------
    // カードフィルタ
    //----------------------------------------
    function hideUnwantedCards() {
        const cards = document.querySelectorAll('.vertical-space--2VG7l.medium--7ss7K');

        cards.forEach(card => {
            const labels = Array.from(card.querySelectorAll('.text-display--3jedW'))
                .map(e => e.textContent.trim());

            const keep = ["販売開始前", "売切れ"];
            const shouldHide = !keep.some(k => labels.includes(k));

            card.style.display = shouldHide ? "none" : "";
        });
    }

    //----------------------------------------
    // カウンター更新
    //----------------------------------------
    function updateCount() {
        const box = insertCounterBox();
        const visibleCards = document.querySelectorAll(
            '.vertical-space--2VG7l.medium--7ss7K:not([style*="display: none"])'
        );
        box.textContent = `Cards: ${visibleCards.length}`;
    }

    //----------------------------------------
    // メインループ
    //----------------------------------------
    setInterval(() => {
        insertCopyButton();
        hideUnwantedCards();
        updateCount();
    }, 800);

})();
