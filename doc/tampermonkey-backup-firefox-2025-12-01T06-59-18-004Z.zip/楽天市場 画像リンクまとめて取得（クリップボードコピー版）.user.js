// ==UserScript==
// @name         楽天市場 画像リンクまとめて取得（クリップボードコピー版）
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  検索結果画像にチェックボックスを付けて、ランダム選択・すべて選択・まとめて取得しJSONをクリップボードにコピー
// @match        https://search.rakuten.co.jp/search/mall/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ===== チェックボックスを画像に追加 =====
    function addCheckboxes() {
        const images = document.querySelectorAll("a.image-link-wrapper--3XCNg > img.image--x5mNi");
        images.forEach(img => {
            if (img.parentElement.querySelector(".raf-checkbox")) return;

            const wrapper = img.parentElement;
            wrapper.style.position = "relative";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "raf-checkbox";
            checkbox.style.position = "absolute";
            checkbox.style.top = "10px";
            checkbox.style.left = "10px";
            checkbox.style.zIndex = "1000";
            checkbox.style.transform = "scale(2.0)";
            checkbox.addEventListener("click", e => e.stopPropagation());

            wrapper.appendChild(checkbox);
        });
    }

    addCheckboxes();

    // 無限スクロール対応
    const observer = new MutationObserver(() => addCheckboxes());
    observer.observe(document.body, { childList: true, subtree: true });

    // ===== UIパネルを右上に作成 =====
    const controlPanel = document.createElement("div");
    controlPanel.style.position = "fixed";
    controlPanel.style.top = "20px";
    controlPanel.style.right = "20px";
    controlPanel.style.zIndex = "10000";
    controlPanel.style.display = "flex";
    controlPanel.style.flexDirection = "column";
    controlPanel.style.gap = "8px";
    controlPanel.style.background = "rgba(0,0,0,0.6)";
    controlPanel.style.padding = "10px";
    controlPanel.style.borderRadius = "6px";
    controlPanel.style.boxShadow = "0 2px 6px rgba(0,0,0,0.4)";
    document.body.appendChild(controlPanel);

    function styleButton(btn, color="red") {
        btn.style.fontSize = "12px";
        btn.style.backgroundColor = color;
        btn.style.color = "white";
        btn.style.border = "none";
        btn.style.borderRadius = "4px";
        btn.style.cursor = "pointer";
        btn.style.padding = "4px 8px";
    }

    // UIボタン作成
    const checkAllBtn = document.createElement("button");
    checkAllBtn.textContent = "すべてチェック";
    styleButton(checkAllBtn, "orange");
    controlPanel.appendChild(checkAllBtn);

    const selectBox = document.createElement("select");
    [10,20,30,40].forEach(num => {
        const opt = document.createElement("option");
        opt.value = num;
        opt.textContent = num;
        selectBox.appendChild(opt);
    });
    selectBox.style.fontSize = "12px";
    controlPanel.appendChild(selectBox);

    const randomCheckBtn = document.createElement("button");
    randomCheckBtn.textContent = "ランダムチェック";
    styleButton(randomCheckBtn, "blue");
    controlPanel.appendChild(randomCheckBtn);

    const uncheckAllBtn = document.createElement("button");
    uncheckAllBtn.textContent = "チェック解除";
    styleButton(uncheckAllBtn, "gray");
    controlPanel.appendChild(uncheckAllBtn);

    const exportButton = document.createElement("button");
    exportButton.textContent = "まとめて取得 (JSONコピー)";
    styleButton(exportButton, "green");
    controlPanel.appendChild(exportButton);

    const wait = ms => new Promise(r => setTimeout(r, ms));

    // ===== ボタン処理 =====
    checkAllBtn.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox").forEach(cb => cb.checked = true);
        //alert("すべてチェックしました！");
    });

    randomCheckBtn.addEventListener("click", () => {
        const allBoxes = Array.from(document.querySelectorAll("input.raf-checkbox"));
        const requiredNum = parseInt(selectBox.value, 10);

        if (allBoxes.length === 0) {
            alert("チェック対象が見つかりません！");
            return;
        }

        allBoxes.forEach(cb => cb.checked = false);
        const shuffled = allBoxes.sort(() => Math.random() - 0.5);
        const selected = shuffled.slice(0, requiredNum);
        selected.forEach(cb => cb.checked = true);
        console.log(`ランダムチェック: ${requiredNum}件`);
    });

    uncheckAllBtn.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox:checked").forEach(cb => cb.checked = false);
        //alert("すべて解除しました！");
    });

    // ===== まとめて取得 (ページ開かず) =====
    exportButton.addEventListener("click", async () => {
        const checkedBoxes = document.querySelectorAll("input.raf-checkbox:checked");
        if (checkedBoxes.length === 0) {
            //alert("まずチェックしてください！");
            return;
        }

        const results = [];
        let index = 1;
        const jstTime = new Date().toLocaleString("ja-JP", { weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit' });

        checkedBoxes.forEach(cb => {
            const link = cb.closest("a.image-link-wrapper--3XCNg");
            const img = link.querySelector("img.image--x5mNi");
            const page_url = link.href;
            const image_url = img.src;
            const item_description = img.alt;

            // デバッグ出力
            console.log("画像情報:", { index, page_url, image_url, item_description });

            results.push({
                index: index++,
                timestamp: jstTime,
                image_url,
                item_description,
                page_url,
                status: "未投稿",
                post_url: "",
                ai_caption: ""
            });
        });

        // JSONコピー
        const jsonStr = JSON.stringify(results, null, 2);
        await navigator.clipboard.writeText(jsonStr);
        alert(`クリップボードにコピーしました (${results.length}件)`);
        console.log(jsonStr);
    });

})();
