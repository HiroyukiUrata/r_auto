// ==UserScript==
// @name         Rakuten アフィ高ランキング JSON出力＋クリップボード保存版
// @namespace    http://tampermonkey.net/
// @version      2.1
// @description  チェックした楽天アフィ高ランキングカードから商品情報をJSON出力し、クリップボードに保存
// @match        https://affiliate.rakuten.co.jp/link/high_ranking*
// @grant        GM_setClipboard
// ==/UserScript==

(function() {
    'use strict';

    // 日時フォーマット（例：2025/11/13(木) 18:39:12）
    function getFormattedTimestamp() {
        const now = new Date();
        const week = ["日", "月", "火", "水", "木", "金", "土"];
        const w = week[now.getDay()];
        const pad = n => n.toString().padStart(2, "0");
        return `${now.getFullYear()}/${pad(now.getMonth()+1)}/${pad(now.getDate())}(${w}) ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    }

    // 画像にチェックボックス追加
    function addCheckboxes() {
        const images = document.querySelectorAll("div.raf-ranking__imageContainer img.ranking-thumbnail");
        images.forEach(img => {
            if (img.parentElement.querySelector(".raf-checkbox")) return;

            const wrapper = img.parentElement;
            wrapper.style.position = "relative";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "raf-checkbox";
            checkbox.style.position = "absolute";
            checkbox.style.top = "17px";
            checkbox.style.left = "17px";
            checkbox.style.zIndex = "1000";
            checkbox.style.transform = "scale(2.0)";
            checkbox.addEventListener("click", e => e.stopPropagation());

            wrapper.appendChild(checkbox);
        });
    }

    addCheckboxes();
    const observer = new MutationObserver(() => addCheckboxes());
    observer.observe(document.body, { childList: true, subtree: true });

    // ボタン生成ヘルパー
    function createButton(text, bottom, right, color) {
        const btn = document.createElement("button");
        btn.textContent = text;
        btn.style.position = "fixed";
        btn.style.bottom = bottom + "px";
        btn.style.right = right + "px";
        btn.style.zIndex = "10000";
        btn.style.padding = "10px";
        btn.style.backgroundColor = color;
        btn.style.color = "white";
        btn.style.fontWeight = "bold";
        btn.style.border = "none";
        btn.style.borderRadius = "5px";
        btn.style.cursor = "pointer";
        document.body.appendChild(btn);
        return btn;
    }

    const exportButton = createButton("チェック商品のJSONをコピー", 20, 20, "green");
    const checkAllButton = createButton("全部チェック", 60, 20, "blue");
    const uncheckAllButton = createButton("チェック解除", 100, 20, "red");

    // 全チェック
    checkAllButton.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox").forEach(cb => cb.checked = true);
    });

    // チェック解除
    uncheckAllButton.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox").forEach(cb => cb.checked = false);
    });

    // JSON出力＋クリップボード保存
    exportButton.addEventListener("click", () => {
        const checkedBoxes = document.querySelectorAll("input.raf-checkbox:checked");
        if (checkedBoxes.length === 0) {
            alert("まずチェックしてください！");
            return;
        }

        const timestamp = getFormattedTimestamp();
        const result = [];
        let index = 1;

        checkedBoxes.forEach(cb => {
            const li = cb.closest("li.raf-ranking__item");
            if (!li) return;

            const image = li.querySelector("img.ranking-thumbnail");
            const nameLink = li.querySelector("a.raf-ranking__name");
            const pageUrl = nameLink ? nameLink.href : "";

            const item = {
                index: index++,
                timestamp: timestamp,
                image_url: image ? image.src : "",
                item_description: nameLink ? nameLink.textContent.trim() : "",
                page_url: pageUrl,
                status: "未投稿",
                post_url: "",
                ai_caption: ""
            };

            result.push(item);
        });

        const jsonText = JSON.stringify(result, null, 2);
        console.log("✅ JSON出力結果:", result);

        // クリップボードにコピー
        if (typeof GM_setClipboard !== "undefined") {
            GM_setClipboard(jsonText);
        } else {
            navigator.clipboard.writeText(jsonText).catch(err => console.error("Clipboard error:", err));
        }

        alert("✅ JSONをクリップボードにコピーしました！（Ctrl+Vで貼り付けできます）");
    });

})();
