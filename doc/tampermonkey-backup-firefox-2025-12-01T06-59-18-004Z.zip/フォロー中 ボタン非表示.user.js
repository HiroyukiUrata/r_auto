// ==UserScript==
// @name         フォロー中 ボタン非表示
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  「フォロー中」になったら親のボタンごと非表示にする（未フォローは残す）
// @match        https://room.rakuten.co.jp/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function hideFollowedButtons() {
        document.querySelectorAll('.border-button').forEach(div => {
            const active = div.querySelector('span.active.icon-follow');
            const follow = div.querySelector('span.follow.icon-follow');

            // フォロー中が表示されていて、フォローが非表示なら → 消す
            if (
                active && !active.classList.contains("ng-hide") && // フォロー中が見えている
                follow && follow.classList.contains("ng-hide")     // フォローが隠れている
            ) {
                div.style.display = "none";
            } else {
                div.style.display = ""; // 未フォローの場合は残す
            }
        });
    }

    // 初回実行
    hideFollowedButtons();

    // Angular の動的変更を監視
    const observer = new MutationObserver(hideFollowedButtons);
    observer.observe(document.body, { childList: true, subtree: true, attributes: true });
})();
