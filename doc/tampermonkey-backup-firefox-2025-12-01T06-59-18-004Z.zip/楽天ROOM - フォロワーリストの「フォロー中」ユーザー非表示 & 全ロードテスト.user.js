// ==UserScript==
// @name         楽天ROOM - フォロワーリストの「フォロー中」ユーザー非表示 & 全ロードテスト
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  楽天ROOMのフォロワー/フォロー中リストモーダル内で、無限スクロールによる全カードロードと「フォロー中」ユーザーの非表示処理をテストします。
// @author       ModalAnalyzer
// @match        https://room.rakuten.co.jp/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // --- 【DOM構造の分析と仮定セレクタ】 ---
    const stableCardWrapperSelector = '.block--_IJiJ.padding-top-xxsmall--QPDIl';
    const scrollContainerSelector = 'div#userList';
    const MAX_SCROLLS = 10;
    const SCROLL_DELAY_MS = 2000; // 読み込みを待つ時間 (2秒)

    // --- ユーティリティ関数 ---
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    /**
     * モーダル内の無限スクロールを完了させ、「フォロー中」のユーザーカードを事前に非表示にする。
     * @param {Element} scrollContainer - スクロール要素（通常は div#userList）
     */
    async function scrollModalAndHideFollowedUsers(scrollContainer) {
        console.log("--- モーダル内の無限スクロールと「フォロー中」ユーザーの事前非表示を開始します。---");

        // 1. 無限スクロール処理 (コンテンツがロードされなくなるまで)
        let scrollCount = 0;
        let lastHeight = 0;

        while (scrollCount < MAX_SCROLLS) {
            const currentHeight = scrollContainer.scrollHeight;

            if (currentHeight === lastHeight) {
                console.log(`[スクロール完了] 高さ不変を確認しました。総スクロール回数: ${scrollCount}`);
                break;
            }

            lastHeight = currentHeight;

            // モーダル内の要素を最下部までスクロール
            scrollContainer.scrollTop = scrollContainer.scrollHeight;

            console.log(`[スクロール実行] ${scrollCount + 1}/${MAX_SCROLLS}回目。次の読み込みを ${SCROLL_DELAY_MS}ms 待ちます...`);
            await sleep(SCROLL_DELAY_MS);
            scrollCount++;
        }

        if (scrollCount >= MAX_SCROLLS) {
            console.warn(`[警告] 最大スクロール回数 (${MAX_SCROLLS}回) に達しましたが、終端に到達したか確認できませんでした。`);
        }

        // 2. 「フォロー中」カードの非表示処理
        try {
            const allCards = document.querySelectorAll(stableCardWrapperSelector);
            let hiddenCount = 0;

            allCards.forEach(card => {
                // Playwrightの :has-text("フォロー中") を JavaScript でシミュレーション
                if (card.textContent.includes("フォロー中")) {
                    card.style.display = 'none';
                    hiddenCount++;
                    // オプション: どのユーザーを非表示にしたか確認
                    // const userName = card.querySelector('span[class*="profile-name"]') ? card.querySelector('span[class*="profile-name"]').textContent.trim() : '不明なユーザー';
                    // console.log(`[非表示] ユーザー: ${userName}`);
                }
            });

            console.log(`[非表示完了] 安定セレクタに一致し、「フォロー中」だったカード ${hiddenCount} 件を非表示にしました。`);

        } catch (e) {
            console.error(`[エラー] 「フォロー中」カードの非表示処理中にエラーが発生しました:`, e);
        }

        console.log("--- テスト処理を完了しました。フォローするボタンが残っているか確認してください。---");
    }

    /**
     * メイン実行ロジック
     * MutationObserverを使用して、モーダルが開いたことを検出する。
     */
    function main() {
        const targetNode = document.body;
        const config = { childList: true, subtree: true };

        const observerCallback = function(mutationsList, observer) {
            // モーダルがDOMに追加されたかを確認（モーダルは body の直下に追加されることが多い）
            // div#userList が存在するかどうかで判断する
            const scrollContainer = document.querySelector(scrollContainerSelector);

            if (scrollContainer) {
                // モーダルを検出したら、オブザーバーを停止し、処理を開始する
                observer.disconnect();
                console.log("[検出] フォロワーリストモーダルが検出されました。処理を開始します。");

                // 非同期関数を実行
                scrollModalAndHideFollowedUsers(scrollContainer);
            }
        };

        // MutationObserverを生成し、DOMの変化を監視
        const observer = new MutationObserver(observerCallback);
        observer.observe(targetNode, config);

        console.log("Tampermonkeyスクリプトが起動しました。フォロワーリストモーダルの表示を待機しています...");
    }

    // スクリプトのエントリーポイント
    main();

})();