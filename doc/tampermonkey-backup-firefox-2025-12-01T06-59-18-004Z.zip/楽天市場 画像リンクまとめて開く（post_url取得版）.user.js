// ==UserScript==
// @name         楽天市場 画像リンクまとめて開く（post_url取得版）
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  チェック画像のリンク先からROOMに投稿リンクを取得してJSON化
// @match        https://search.rakuten.co.jp/search/mall/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// ==/UserScript==

(function() {
    'use strict';

    const mainTab = window;

    // ===== チェックボックス追加 =====
    function addCheckboxes() {
        const images = document.querySelectorAll("a.image-link-wrapper--3XCNg > img.image--x5mNi");
        images.forEach(img => {
            if (img.parentElement.querySelector(".raf-checkbox")) return;

            const wrapper = img.parentElement;
            wrapper.style.position = "relative";

            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.className = "raf-checkbox";
            checkbox.style.position = "absolute";
            checkbox.style.top = "10px";
            checkbox.style.left = "10px";
            checkbox.style.zIndex = "1000";
            checkbox.style.transform = "scale(2.0)";
            checkbox.addEventListener("click", e => e.stopPropagation());

            wrapper.appendChild(checkbox);
        });
    }
    addCheckboxes();

    // 無限スクロール対応
    const observer = new MutationObserver(() => addCheckboxes());
    observer.observe(document.body, { childList: true, subtree: true });

    // ===== UIパネル =====
    const controlPanel = document.createElement("div");
    controlPanel.style.position = "fixed";
    controlPanel.style.top = "20px";
    controlPanel.style.right = "20px";
    controlPanel.style.zIndex = "10000";
    controlPanel.style.display = "flex";
    controlPanel.style.flexDirection = "column";
    controlPanel.style.gap = "8px";
    controlPanel.style.background = "rgba(0,0,0,0.6)";
    controlPanel.style.padding = "10px";
    controlPanel.style.borderRadius = "6px";
    controlPanel.style.boxShadow = "0 2px 6px rgba(0,0,0,0.4)";
    document.body.appendChild(controlPanel);

    function styleButton(btn, color="red") {
        btn.style.fontSize = "12px";
        btn.style.backgroundColor = color;
        btn.style.color = "white";
        btn.style.border = "none";
        btn.style.borderRadius = "4px";
        btn.style.cursor = "pointer";
        btn.style.padding = "4px 8px";
    }

    const checkAllBtn = document.createElement("button");
    checkAllBtn.textContent = "すべてチェック";
    styleButton(checkAllBtn, "orange");
    controlPanel.appendChild(checkAllBtn);

    const selectBox = document.createElement("select");
    [10,20,30,40].forEach(num => {
        const opt = document.createElement("option");
        opt.value = num;
        opt.textContent = num;
        selectBox.appendChild(opt);
    });
    selectBox.style.fontSize = "12px";
    controlPanel.appendChild(selectBox);

    const randomCheckBtn = document.createElement("button");
    randomCheckBtn.textContent = "ランダムチェック";
    styleButton(randomCheckBtn, "blue");
    controlPanel.appendChild(randomCheckBtn);

    const uncheckAllBtn = document.createElement("button");
    uncheckAllBtn.textContent = "チェック解除";
    styleButton(uncheckAllBtn, "gray");
    controlPanel.appendChild(uncheckAllBtn);

    const openButton = document.createElement("button");
    openButton.textContent = "まとめて情報取得";
    styleButton(openButton, "green");
    controlPanel.appendChild(openButton);

    const wait = ms => new Promise(r => setTimeout(r, ms));

    // ===== ボタンイベント =====
    checkAllBtn.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox").forEach(cb => cb.checked = true);
        alert("すべてチェックしました！");
    });

    randomCheckBtn.addEventListener("click", () => {
        const allBoxes = Array.from(document.querySelectorAll("input.raf-checkbox"));
        const requiredNum = parseInt(selectBox.value, 10);
        if (allBoxes.length === 0) { alert("チェック対象が見つかりません！"); return; }
        allBoxes.forEach(cb => cb.checked = false);
        const shuffled = allBoxes.sort(() => Math.random() - 0.5);
        const selected = shuffled.slice(0, requiredNum);
        selected.forEach(cb => cb.checked = true);
        console.log(`ランダムチェック: ${requiredNum}件`);
    });

    uncheckAllBtn.addEventListener("click", () => {
        document.querySelectorAll("input.raf-checkbox:checked").forEach(cb => cb.checked = false);
        alert("すべて解除しました！");
    });

    // ===== まとめて情報取得 =====
    openButton.addEventListener("click", async () => {
        const checkedBoxes = Array.from(document.querySelectorAll("input.raf-checkbox:checked"));
        if (checkedBoxes.length === 0) { alert("まずチェックしてください！"); return; }

        const records = [];
        let index = 0;

        for (let cb of checkedBoxes) {
            const link = cb.closest("a.image-link-wrapper--3XCNg");
            if (!link) continue;

            const image = link.querySelector("img.image--x5mNi");
            const pageUrl = link.href;
            const itemDescription = image?.alt || "";

            // GM_xmlhttpRequestでリンク先HTMLを取得してROOMリンクを探す
            const postUrl = await new Promise(resolve => {
                GM_xmlhttpRequest({
                    method: "GET",
                    url: pageUrl,
                    onload: function(response) {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(response.responseText, "text/html");
                        const postLink = [...doc.querySelectorAll('a')].find(a => a.textContent.includes("ROOMに投稿"));
                        resolve(postLink?.href || "");
                    }
                });
            });

            const timestamp = new Date().toLocaleString("ja-JP", { weekday:"short", year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", minute:"2-digit", second:"2-digit" });

            records.push({
                index: index++,
                page_url: pageUrl,
                item_description: itemDescription,
                status: "未投稿",
                post_url: postUrl,
                ai_caption: ""
            });
        }

        // クリップボードコピー
        GM_setClipboard(JSON.stringify(records, null, 2));
        alert(`情報取得完了。${records.length}件コピーしました！`);
    });

})();
